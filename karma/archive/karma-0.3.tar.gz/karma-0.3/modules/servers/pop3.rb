#!/usr/bin/env ruby
#
#
#

require 'gserver'
require 'servicemanager'

module Karma
    class Pop3Server < GServer
        def initialize(address = "0.0.0.0", port = 110)
            super(port, address)
        end
        
        def serve(io)
            ip = io.peeraddr[3]
            user = ""
            pass = ""
            
            io.print "+OK\r\n"
            
            while ((line = io.gets().chomp()))
                case line
                when /quit/i
                    io.print "+OK\r\n"
                    break
                    
                when /user\s(.*)/i
                    user = $1
                    io.print "+OK\r\n"
                    
                when /pass\s(.*)/i
                    pass = $1
                    
                    puts "POP3: #{ip} #{user}/#{pass}"
                    
                    io.print "-ERR\r\n"
                    
                else
                    io.print "-ERR\r\n"
                end
            end
        end
    end

    ServiceManager.instance.add(Pop3Server)

end
