#!/usr/bin/env ruby
#
#
#

require 'resolv'
require 'servicemanager'

module Karma
    #
    # Simple DNS server to respond to every A? question with A <host>
    #
    class DnsServer
        def initialize(address = "0.0.0.0", port = 53)
            @port = port
            @address = address
        end

        def start()
            @thread = Thread.new() {
                # MacOS X workaround
                Socket.do_not_reverse_lookup = true
        
                @sock = UDPSocket.new()
                @sock.setsockopt(Socket::SOL_SOCKET, Socket::SO_REUSEADDR, 1)
                @sock.bind(@address, @port)
                while true
                    packet, addr = @sock.recvfrom(65535)
                    request = Resolv::DNS::Message.decode(packet)
                
                    #
                    # XXX: Track request IDs by requesting IP address and port
                    #
                    # Windows XP SP1a: UDP source port constant, 
                    #  sequential IDs since boot time
                    # Windows XP SP2: Randomized IDs
                    #
                    # Debian 3.1: Static source port (32906) until timeout, 
                    #  randomized IDs
                    #
                    print "DNS: #{addr[3].to_s()}.#{addr[1].to_s()}: #{request.id.to_s()}"
                    request.each_question {|name, typeclass|
                        tc_s = typeclass.to_s().gsub(/^Resolv::DNS::Resource::/, "")
                        
                        print " #{tc_s} #{name}"
                        if typeclass == Resolv::DNS::Resource::IN::A
                        
                            # Special fingerprinting name lookups:
                            #
                            # _isatap -> XP SP = 0
                            # isatap.localdomain -> XP SP >= 1
                            # teredo.ipv6.microsoft.com -> XP SP >= 2
                            #
                            # time.windows.com -> windows ???
                            # wpad.localdomain -> windows ???
                            #
                            # <hostname> SOA -> windows XP self hostname lookup
                            #
                            
                            request.qr = 1
                            request.ra = 1
                            answer = Resolv::DNS::Resource::IN::A.new(@address)
                            request.add_answer(name, 60, answer)
                        end
                    }
                    print "\n"
                    
                    @sock.send(request.encode(), 0, addr[3], addr[1])
                end
            }
        end

        def stop()
            @thread.kill
            @sock.close
        end
    end

    ServiceManager.instance.add(DnsServer)

end




