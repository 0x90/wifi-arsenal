#!/usr/bin/env ruby
#
#
#

if ARGV.length < 1
    puts "usage: #{$0} <ip address>"
    exit 0
end

# Scan directory and make these autoloads
load("servicemanager.rb", false);
load("dns.rb", false)
load("http.rb", false)
load("pop3.rb", false)

Thread.abort_on_exception = true

sm = Karma::ServiceManager.instance
sm.start(ARGV[0])

trap("INT") {
    sm.shutdown()
    exit 0
}

trap("QUIT") {
    sm.reload()
}

# Yield main thread indefinitely
sleep()
