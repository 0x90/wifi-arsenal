#!/usr/bin/env ruby
#
# Service Manager
#
# Dino Dai Zovi <ddz@theta44.org>
#

module Karma
    
    #
    # Service interface
    #
    class Service
        def initialize(address = "0.0.0.0")
        end

        def start()
        end

        def stop()
        end

    end
    
    require 'singleton'

    class ServiceManager
        include Singleton

        def initialize()
            @server_classes = []
            @servers = []
        end

        def add(s)
            @server_classes.push(s)
        end

        def start(address = "0.0.0.0")
            $stderr.print "ServiceManager: Starting services...\n"
            @server_classes.each {|s|
                $stderr.print "  " + s.name + " "
                server = s.new(address)
                server.start()
                @servers.push(server)
                $stderr.print "\n"
            }
            $stderr.print "\n"
        end

        def shutdown()
            $stderr.print "ServiceManager: Shutting down...\n"
            @servers.each {|s|
                $stderr.print "  " + s.class.name + " "
                s.stop()
                $stderr.print "\n"
            }
            @servers = []
            $stderr.print "\n"
        end
    end
end

