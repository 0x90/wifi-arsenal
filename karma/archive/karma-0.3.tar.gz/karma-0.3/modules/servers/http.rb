#!/usr/bin/env ruby
#
# HTTP Exploit Proxy/Server
#
# This module is the delivery mechanism for HTTP client-side
# exploits.  Most exploits require just file distribution and just
# register themselves as a virtual directory.  The exploits may also
# register notifications when certain files are retrieved in order to
# gauge progress or success.
# 
# Dino Dai Zovi <ddz@theta44.org>
#

require 'webrick'
require 'webrick/httpproxy'
require 'resolv-replace'    # to make sockets non-blocking

module Karma

    #
    # Make WEBrick::HTTPRequest URIs mutable by adding this method to
    # HTTPRequest objects at runtime.
    #
    module MutableHTTPRequest
        def update_uri(uri)
            @unparsed_uri = uri
            @request_uri = parse_uri(@unparsed_uri)
        end
    end

    class HttpServer < WEBrick::HTTPProxyServer
        
        def initialize(address = "0.0.0.0", port = 80)
            super(:Port => port,
                  :BindAddress => address,
                  :ProxyVia => true,
                  :ServerType => Thread);

            # XXX: Just for testing, remove this later.
            mount('/', WEBrick::HTTPServlet::FileHandler, '.')
        end
        
        def service(req, res)
            # Detect looping back into ourselves
            if req['via'] == @via
                raise WEBrick::HTTPStatus::NotFound
            else
                host = req["Host"]
                
                if (host && !(host =~ %r!karma!i) && 
                          !(req.unparsed_uri =~ %r!~http://!))
                    req.extend MutableHTTPRequest
                    req.update_uri("http://" + host + req.unparsed_uri)
                end
                
                super(req, res)
            end
        end
        
        def proxy_service(req, res)
            #
            # XXX: Test injection criteria here
            #
            
            super(req, res)
        end
        
        #
        # XXX: Method to add exploit injectors
        #

        #
        # XXX: Method to add exploit servlets
        # - register notifications on specific files being retrieved
        #

        def add_exploit_vdir(path, vpath)
            mount(vpath, WEBrick::HTTPServlet::FileHandler, path)
        end

    end

    ServiceManager.instance.add(HttpServer)
end
