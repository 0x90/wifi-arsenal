/*
 * AirTap: Capture IEEE 802.11 packets
 *
 * Dino Dai Zovi <ddz@theta44.org>
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pcap.h>

#include <net80211/ieee80211.h>
#include <net80211/ieee80211_radiotap.h>

#include "airtap.h"

#define TO_MS 10

int init_pcap(char*);

/*
 * Datalink decoder table
 */
typedef void (*datalink_decoder)(const u_char*);

static void decode_ieee802_11_radio(const u_char*);
static void decode_ieee802_11(const u_char*);

struct {
    int              datalink;
    datalink_decoder decoder;
} datalink_decoders[] = {
    /* Ordered by perference in case interface supports multiple */
    {DLT_IEEE802_11_RADIO, decode_ieee802_11_radio},
    //{DLT_IEEE802_11, decode_ieee802_11},
    //{DLT_PRISM_HEADER, decode_prism_header},
    //{DLT_AIRONET_HEADER, decode_aironet_header},
    //{DLT_IEEE802_11_RADIO_AVS, decode_ieee802_11_radio_avs},
    {-1, NULL}
};

static int does_file_exist(char* path)
{
    struct stat sb;

    return (stat(path, &sb) == 0 && (sb.st_mode & S_IFMT) == S_IFREG) ? 1 : 0;
}

static void handle_packet(u_char* u, const struct pcap_pkthdr* pkthdr,
                          const u_char* pkt)
{
    datalink_decoder decoder = (datalink_decoder)u;

    (*decoder)(pkt);
}

struct at_hook {
    struct at_hook* next;
    unsigned char   type;
    unsigned char   subtype;
    unsigned char   dir;
    at_hook_t       hook;
};

/* dir, type, subtype */
struct at_hook* hooks[4][16] = {
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

void airtap_add_hook(unsigned int type, unsigned int subtype,
                     unsigned int dir, at_hook_t hook)
{
    struct at_hook** h;

    /*
     * Handle wild cards
     */
    
    for (h = &(hooks[type >> 2][subtype >> 4]); *h != NULL; h = &(*h)->next);

    if ((*h = malloc(sizeof(struct at_hook))) == NULL) {
        perror("airtap_add_hook: malloc");
        exit(EXIT_FAILURE);
    }
    
    (*h)->next = NULL;
    (*h)->type = type;
    (*h)->subtype = subtype;
    (*h)->dir = dir;
    (*h)->hook = hook;
}

static void call_hooks(unsigned int type,
                       unsigned int subtype,
                       unsigned int dir,
                       const u_char* frame)
{
    unsigned int t = type >> 2, s = subtype >> 4;
    struct at_hook* h;
    
    assert(t < 3 && s <= 15);

    /* Specific type/subtype handler */
    for (h = hooks[t][s]; h; h = h->next)
        if (h->dir == AT_DIR_ALL || h->dir == dir)
            (*h->hook)(frame);
                
    /* All subtypes handler */
    for (h = hooks[3][t]; h; h = h->next)
        if (h->dir == AT_DIR_ALL || h->dir == dir)
            (*h->hook)(frame);

    /* All types handler */
    for (h = hooks[3][4]; h; h = h->next)
        if (h->dir == AT_DIR_ALL || h->dir == dir)
            (*h->hook)(frame);
}

int airtap_loop(char* file_or_int)
{
    char pcap_errbuf[PCAP_ERRBUF_SIZE];
    pcap_t* pcap;
    int* datalinks, n_datalinks, i, j;
    datalink_decoder decode_datalink = NULL;
    
    /*
     * Read packets from pcap interface or file
     */
    
    if (does_file_exist(file_or_int)) {
        if (!(pcap = pcap_open_offline(file_or_int, pcap_errbuf))) {
            fprintf(stderr, "init_pcap: pcap_open_offline: %s\n", pcap_errbuf);
            exit(EXIT_FAILURE);
        }
    }
    else {
        if (!(pcap = pcap_open_live(file_or_int,
                                    0,    /* snaplen: whole packet */
                                    1,    /* promisc: yes */
                                    TO_MS,
                                    pcap_errbuf))) {
            fprintf(stderr, "init_pcap: pcap_open_live: %s\n", pcap_errbuf);
            exit(EXIT_FAILURE);
        }
    }

    /*
     * Select best available datalink
     */
    
    if ((n_datalinks = pcap_list_datalinks(pcap, &datalinks)) < 0) {
        pcap_perror(pcap, "init_pcap: pcap_list_datalinks");
        exit(EXIT_FAILURE);
    }

    for (i = 0; !decode_datalink && datalink_decoders[i].datalink > 0; i++) {
        for (j = 0; j < n_datalinks; j++) {
            if (datalink_decoders[i].datalink == datalinks[j]) {
                if (pcap_set_datalink(pcap,
                                      datalink_decoders[i].datalink) < 0) {
                    pcap_perror(pcap, "init_pcap: pcap_set_datalink");
                    exit(EXIT_FAILURE);
                }
                
                decode_datalink = datalink_decoders[i].decoder;
            }
        }
    }

    if (!decode_datalink) {
        fprintf(stderr, "init_pcap: no suitable datalink decoder found\n");
        exit(EXIT_FAILURE);
    }

    /*
     * Read packets forever
     */
    return pcap_loop(pcap, -1, handle_packet, (u_char*)decode_datalink);
}

/*********************************************************************
 *                   BSD Radiotap Datalink support                   *
 *********************************************************************/

/* Copied from FreeBSD header in notoriously bad style */
struct wi_rx_radiotap_header {
        struct ieee80211_radiotap_header wr_ihdr;
        u_int8_t        wr_flags;
        u_int8_t        wr_rate;
        u_int16_t       wr_chan_freq;
        u_int16_t       wr_chan_flags;
        u_int8_t        wr_antsignal;
        u_int8_t        wr_antnoise;
};

void decode_ieee802_11_radio(const u_char* pkt)
{
    /*
     * XXX: We should really not hardcode static radiotap header types
     */
    struct wi_rx_radiotap_header* rt_hdr =
        (struct wi_rx_radiotap_header*)pkt;
    struct ieee80211_frame* frame =
        (struct ieee80211_frame*)
        (pkt + sizeof(struct wi_rx_radiotap_header));
    uint8_t fc0;
    
    assert(rt_hdr->wr_ihdr.it_version == 0);

    fc0 = frame->i_fc[0];
    
    assert((fc0 & IEEE80211_FC0_VERSION_MASK) == IEEE80211_FC0_VERSION_0);

    call_hooks(fc0 & IEEE80211_FC0_TYPE_MASK,
               fc0 & IEEE80211_FC0_SUBTYPE_MASK,
               frame->i_fc[1] & IEEE80211_FC1_DIR_MASK,
               (const u_char*)frame);
}

void decode_ieee802_11(const u_char* frame)
{
    
}
