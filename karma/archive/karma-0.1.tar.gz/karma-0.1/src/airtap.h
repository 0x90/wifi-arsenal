/*
 * AirTap - Wireless Frame Capture
 */

#ifndef _AIRTAP_H_
#define _AIRTAP_H_

#define AT_TYPE_MGMT 0x00
#define AT_TYPE_CNTL 0x04
#define AT_TYPE_DATA 0x08
#define AT_TYPE_ALL  0xFF

#define AT_MGMT_SUBTYPE_ASSOC_REQ   0x00
#define AT_MGMT_SUBTYPE_ASSOC_RSP   0x10
#define AT_MGMT_SUBTYPE_REASSOC_REQ 0x20
#define AT_MGMT_SUBTYPE_REASSOC_RSP 0x30
#define AT_MGMT_SUBTYPE_PROBE_REQ   0x40
#define AT_MGMT_SUBTYPE_PROBE_RSP   0x50
#define AT_MGMT_SUBTYPE_BEACON      0x80
#define AT_MGMT_SUBTYPE_ATIM        0x90
#define AT_MGMT_SUBTYPE_DISASSOC    0xa0
#define AT_MGMT_SUBTYPE_AUTH        0xb0
#define AT_MGMT_SUBTYPE_DEAUTH      0xc0
#define AT_MGMT_SUBTYPE_ALL         0xFF

/* XXX: CNTL subtypes */
#define AT_CNTL_SUBTYPE_ALL         0xFF

/* XXX: DATA subtypes */
#define AT_DATA_SUBTYPE_DATA        0x00
#define AT_DATA_SUBTYPE_ALL         0xFF

#define AT_DIR_NODS   0x00    /* STA -> STA */
#define AT_DIR_TODS   0x01    /* STA -> AP  */
#define AT_DIR_FROMDS 0x02    /* AP  -> STA */
#define AT_DIR_DSTODS 0x03    /* AP  -> AP  */
#define AT_DIR_ALL    0xFF

typedef void (*at_hook_t)(const unsigned char*);

extern int airtap_loop(char* interface_or_file);

extern void airtap_add_hook(unsigned int type,
                            unsigned int subtype,
                            unsigned int dir,
                            at_hook_t hook);

#endif /* _AIRTAP_H_ */
