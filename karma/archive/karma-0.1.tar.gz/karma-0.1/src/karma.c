/*
 * KARMA Attacks Radioed Machines Automatically
 *
 * Dino Dai Zovi <ddz@theta44.org>
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>

#include <sys/types.h>
#include <net80211/ieee80211.h>

#include "airtap.h"
#include "karma.h"

struct sta* sta_list = NULL;

static void dump_sta_info(sta_t* sta)
{
    struct ssid* s;
    
    fprintf(stderr, "STA 0x%.8x %d", sta->staid, sta->state);
    
    for (s = sta->probed_networks; s; s = s->next)
        fprintf(stderr, " %s(%d)", s->ssid, s->seq);

    fprintf(stderr, "\n");
}

void on_probe_req(const unsigned char* f)
{
    struct ieee80211_frame* frame =
        (struct ieee80211_frame*)f;
    const unsigned char* body = f + sizeof(struct ieee80211_frame);

    char* ssid;
    unsigned int staid;
    u_int16_t seq;


    struct ssid** s;
    struct sta** sta_iter;
    struct sta* sta_entry = NULL;
    sta_t* sta = NULL;
    int do_update = 0;
    
    /*
     * Probe request is:
     * SSID, Supported rates
     */

    assert(body[0] == 0);

    if (body[1] == 32) {    /* Garbage probe requests */
        return;
    }
    else if (body[1] > 0) {
        ssid = malloc(body[1] + 1);
        strncpy(ssid, body + 2, body[1]);
        ssid[body[1]] = '\0';
    }
    else {
        ssid = strdup("<broadcast>");
    }

    /*
     * addr2 is STA address
     */

    memcpy(&seq, &frame->i_seq, sizeof(seq));
    seq = (seq & 0xfff0) >> 4;
    
    staid =
        (frame->i_addr2[2] << 24) |
        (frame->i_addr2[3] << 16) |
        (frame->i_addr2[4] << 8) |
        (frame->i_addr2[5]);

    /*
     * Find station entry in list
     */
    for (sta_iter = &sta_list; *sta_iter; sta_iter = &((*sta_iter)->next)) {
        if (((*sta_iter)->sta)->staid == staid) {
            sta_entry = *sta_iter;
            *sta_iter = (*sta_iter)->next;
            break;
        }
    }

    /*
     * Allocate a new one if it wasn't found
     */
    if (!sta_entry) {
        sta_entry = malloc(sizeof(struct sta));
        sta_entry->sta = malloc(sizeof(sta_t));

        
        sta_entry->sta->staid = staid;
        memcpy(&(sta_entry->sta->mac), &(frame->i_addr2), 6);
        sta_entry->sta->last_seq = 0;
        sta_entry->sta->state = UNKNOWN;
        sta_entry->sta->probed_networks = NULL;

        do_update = 1;
    }
    
    /*
     * Update station information
     */
    sta = sta_entry->sta;
    sta->last_seq = seq;

    /*
     * Find SSID in this station's probed networks list and add it if
     * it wasn't found.
     */
    for (s = &(sta->probed_networks); *s; s = &(*s)->next) {
        if (strcmp((*s)->ssid, ssid) == 0) {
            /*
             * Move to front
             */
            struct ssid* s2 = *s;

            (*s) = (*s)->next;
            s2->next = sta->probed_networks;
            sta->probed_networks = s2;
            s = &(sta->probed_networks);
            
            break;
        }
    }

    if (*s == NULL) {
        struct ssid* s2;
        
        if ((s2 = malloc(sizeof(struct ssid))) == NULL) {
            perror("on_probe_req: malloc");
        }
        
        s2->next = sta->probed_networks;
        s2->ssid = strdup(ssid);
        s2->seq = seq;

        sta->probed_networks = s2;
        
        s = &(sta->probed_networks);

        do_update = 1;
    }
    else {
        (*s)->seq = seq;
    }

    /*
     * Put station entry back in list
     */
    sta_entry->next = sta_list;
    sta_list = sta_entry;
    
    free(ssid);
    
    //dump_sta_info(sta);

    if (do_update)
        kui_update();
}

int main(int argc, char* argv[])
{
    /*
     * Install hooks
     */
    airtap_add_hook(AT_TYPE_MGMT,
                    AT_MGMT_SUBTYPE_PROBE_REQ,
                    AT_DIR_NODS,
                    on_probe_req);

    kui_init();
    
    /*
     * Deliver justice.
     */
    return airtap_loop(argv[1]);
}
